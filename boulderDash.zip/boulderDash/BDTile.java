public enum BDTile {
         EMPTY              , 
         DIRT               , 
         WALL               , 
         ROCK               , 
         FALLINGROCK        , 
         DIAMOND            , 
         FALLINGDIAMOND     , 
         AMOEBA             , 
         FIREFLY            , 
         BUTTERFLY          , 
         EXIT               , 
         PLAYER             
}