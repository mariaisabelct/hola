import java.io.*;
import java.util.*;
import javax.xml.parsers.*;
import javax.xml.xpath.*;
import org.w3c.dom.*;

public class BDLevelReader{
   
    private final int WIDTH = 40;
    private final int HEIGHT = 22;
    private Document doc;
    private BDTile[][] field = new BDTile[WIDTH][HEIGHT];
    private int diamondsNeeded;

    public int readLevels(String filename) throws Exception {     
        File f = new File(filename);
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        DocumentBuilder db = dbf.newDocumentBuilder();
        doc = db.parse(f);
        XPathFactory xpf = XPathFactory.newInstance();
        XPath path = xpf.newXPath();
        int numLevel = Integer.parseInt(path.evaluate("count(levelset/level)", doc));
        return numLevel; 
    }
    
    private void readElementsOfType(int level, String name, BDTile value, XPath path) throws Exception {
        int count = Integer.parseInt(path.evaluate("count(levelset/level["+level+"]/" + name + ")", doc));    
        for(int i = 1; i <= count; i++) {
            int x = Integer.parseInt(path.evaluate("levelset/level["+level+"]/" + name + "[" + i + "]/@x", doc));
            int y = Integer.parseInt(path.evaluate("levelset/level["+level+"]/" + name + "[" + i + "]/@y", doc));
            field[x][y] = value;
        }
    }
   
    public void setCurrentLevel(int level) throws Exception {
        
        for(int x = 0; x < WIDTH; x++) {
            for(int y = 0; y < HEIGHT; y++) {
                field[x][y] = BDTile.DIRT;
            }
        }
        
        Map<String, BDTile> map = new HashMap<String, BDTile>();        
        map.put("wall", BDTile.WALL);
        map.put("rock", BDTile.ROCK);
        map.put("diamond", BDTile.DIAMOND);
        map.put("amoeba", BDTile.AMOEBA);
        map.put("dirt", BDTile.DIRT);
        map.put("empty", BDTile.EMPTY);
        map.put("firefly", BDTile.FIREFLY);
        map.put("butterfly", BDTile.BUTTERFLY);
        map.put("exit", BDTile.EXIT);
        map.put("player", BDTile.PLAYER);
        
        NodeList nlist = doc.getElementsByTagName("levelset");          
        Node n = nlist.item(0);                                         
        nlist = n.getChildNodes();                                      
        int lvl = 0;                                                    
        for(int i = 0; lvl < level && i < nlist.getLength(); i++) {
            n = nlist.item(i);
            if(n.getNodeName().equals("level")) { lvl++; }
        }            
        diamondsNeeded = Integer.parseInt(n.getAttributes().getNamedItem("diamonds").getNodeValue()); 
        nlist = n.getChildNodes();
        for(int i = 0; i < nlist.getLength(); i++) {                   
            Node e = nlist.item(i);
            String tag = e.getNodeName();                               
            if(!map.containsKey(tag)) continue;
            NamedNodeMap attr = e.getAttributes();
            int x = Integer.parseInt(attr.getNamedItem("x").getNodeValue());            
            int y = Integer.parseInt(attr.getNamedItem("y").getNodeValue());
            
            field[x][y] = map.get(tag);                                
        }
    }   
    
    public BDTile getTile(int x, int y) { return field[x][y]; }
    public int getDiamondsNeeded() { return diamondsNeeded; }
}