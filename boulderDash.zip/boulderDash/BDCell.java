
public class BDCell
{
     public BDTile tile;
     public Direction flyDir; 
     public int x;
     public int y;
}


