//Maria Consuegra

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.awt.geom.*;
import java.io.*;
import java.util.Random;
import java.util.ArrayList;

public class BoulderDash extends JPanel
{
    private BDLevelReader lr;
    private BDCell[][] gamefield;
    private ArrayList<BDCell> flies;
    private int WIDTH = 40;
    private int HEIGHT = 22;
    private Image i1, i2, i3, i4, i5, i6, i7, i8, i9, i10, i11, i12;
    private int goLevel = 1;
    private int numberDiamonds;
    private int collectedDiamond;
    private JFrame myFrame;
    private Timer timer;
    private Timer clock;
    private long period, startTime, endTime; 
    private long timeLimit = 120;
    private boolean running = true; 
    public Random rnd = new Random(System.currentTimeMillis());

    public BoulderDash (String filename,  JFrame f) throws Exception
    {
        myFrame = f;
        lr = new BDLevelReader();
        lr.readLevels(filename);
        gamefield = new BDCell [WIDTH][HEIGHT];
        flies = new ArrayList<BDCell>();
        setLevel(goLevel);
        this.addKeyListener(new KeyListener1());
        this.setFocusable(true);
        this.requestFocus();
        this.setBackground(Color.BLACK);
        this.setBorder(BorderFactory.createEtchedBorder());
        this.setPreferredSize(new Dimension(WIDTH*25+20, HEIGHT*25 + 20));
        myFrame.setPreferredSize(new Dimension(WIDTH*25+50, HEIGHT*25 + 60));
        myFrame.pack();
        timer = new Timer(1000, new ActionListenerTimer());
        timer.start();
        clock = new Timer(1000, new ActionListenerClock());
        clock.start(); 
        i1 = Toolkit.getDefaultToolkit().getImage("dirt.jpg");
        i2 = Toolkit.getDefaultToolkit().getImage("wall.jpg");
        i3 = Toolkit.getDefaultToolkit().getImage("rock.jpg");
        i4 = Toolkit.getDefaultToolkit().getImage("fallingrock.jpg");
        i5 = Toolkit.getDefaultToolkit().getImage("diamond.jpg");
        i6 = Toolkit.getDefaultToolkit().getImage("fallingdiamond.jpg");                                
        i7 = Toolkit.getDefaultToolkit().getImage("amoeba.jpg");
        i8 = Toolkit.getDefaultToolkit().getImage("firefly.jpg");
        i9 = Toolkit.getDefaultToolkit().getImage("butterfly.jpg");
        i10 = Toolkit.getDefaultToolkit().getImage("exit.jpg");
        i11 = Toolkit.getDefaultToolkit().getImage("player.jpg");
        i12 = Toolkit.getDefaultToolkit().getImage("logo1.png");
        repaint();
    }

    public void log(String s)
    {
        System.out.println(s);
    }

    public void setLevel (int level)  
    {
        try 
        {
            lr.setCurrentLevel(level);
            numberDiamonds = lr.getDiamondsNeeded();
            collectedDiamond = 0;
            startTime = System.currentTimeMillis();
            flies.clear();

            for (int x = 0; x < WIDTH; x++) 
            {    
                for (int y = 0; y < HEIGHT; y++) 
                {
                    gamefield[x][y] = new BDCell();
                    gamefield[x][y].tile = lr.getTile(x,y);
                    gamefield[x][y].x = x;
                    gamefield[x][y].y = y;
                    gamefield[x][y].flyDir = Direction.NONE;

                    if (gamefield[x][y].tile == BDTile.BUTTERFLY || gamefield[x][y].tile == BDTile.FIREFLY)
                    {
                        gamefield[x][y].flyDir = GetRandomDirection();
                        flies.add(gamefield[x][y]);
                    }
                }
            }
        }
        catch(Exception e)
        {
        }    
    }

    public Direction GetRandomDirection()
    {
        int c = rnd.nextInt(4);
        Direction dir = null; 

        if (c == 0)  
        {
            dir = Direction.LEFT; 
        }

        else if (c == 1)  
        {
            dir = Direction.UP; 
        }

        else if (c == 2)  
        {
            dir = Direction.RIGHT; 
        }

        else if (c == 3)  
        {
            dir = Direction.DOWN; 
        }

        return dir; 
    }

    public void paintComponent(Graphics g)
    {
        super.paintComponent(g);    
        Graphics2D g2 = (Graphics2D) g;    
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        for (int x = 0; x < WIDTH; x++) 
        {    
            for (int y = 0; y < HEIGHT; y++) 
            {
                switch(gamefield [x][y].tile){   
                    case EMPTY:  g2.setPaint(Color.BLACK);  g2.fill(new Rectangle2D.Double(x*25 +10, y*25 +10, 24, 24));break;       
                    case DIRT:  g2.drawImage(i1,x*25+10, y*25+10,this);break;    
                    case WALL: g2.drawImage(i2,x*25+10, y*25+10,this);break; 
                    case ROCK: g2.drawImage(i3,x*25+10, y*25+10,this);break; 
                    case FALLINGROCK: g2.drawImage(i4,x*25+10, y*25+10,this);break;
                    case DIAMOND: g2.drawImage(i5,x*25+10, y*25+10,this);break;  
                    case FALLINGDIAMOND: g2.drawImage(i6,x*25+10, y*25+10,this);break;
                    case AMOEBA: g2.drawImage(i7,x*25+10, y*25+10,this);break;    
                    case FIREFLY:g2.drawImage(i8,x*25+10, y*25+10,this);break; 
                    case BUTTERFLY: g2.drawImage(i9,x*25+10, y*25+10,this);break;
                    case EXIT: g2.drawImage(i10,x*25+10, y*25+10,this);break; 
                    case PLAYER: g2.drawImage(i11,x*25+10, y*25+10,this);break;   
                }
            }
        }
        g2.drawImage(i12,16, 6, this);

        g2.setColor(Color.WHITE);
        g2.drawString("Time Limit: " + timeLimit, 112, 550);
        g2.drawString("Time: " + period, 36, 552);
        g2.drawString("Diamonds Required: " + numberDiamonds, 386, 550);    
        g2.drawString("Diamonds Collected: " + collectedDiamond, 236, 550);
    }

    private void amoebaMoves (int x, int y)
    {
        int a = rnd.nextInt(3) - 1;
        int b = rnd.nextInt(3) - 1;
        int t = rnd.nextInt(12);

        if ((gamefield[x+a][y+b].tile == BDTile.DIRT || gamefield[x+a][y+b].tile == BDTile.EMPTY) && (t == 11)) 
        {
            gamefield[x+a][y+b].tile = BDTile.AMOEBA; 
        }
    }

    private void explosion (int x, int y, BDTile filler)
    { 
        for (int i = x-1; i < x+2; i++)
        { 
            for (int j = y-1; j < y+2; j++)
            {
                if (gamefield[i][j].tile != BDTile.WALL)
                { 
                    gamefield[i][j].tile = filler;
                }
            }
        }
    }

    private void playerDied()
    {
        System.out.println ("Player Died. Press R to restart the level"); 
    }

    private class KeyListener1 extends KeyAdapter   
    {  
        public void keyPressed (KeyEvent ke) 
        {
            int kc = ke.getKeyCode(); 
            int playerx = 0;
            int playery = 0;
            boolean playerfound = false; 

            for (int x = 0; x < WIDTH; x++) 
            {    
                for (int y = 0; y < HEIGHT; y++) 
                {
                    if (gamefield[x][y].tile == BDTile.PLAYER)
                    {
                        playerfound = true;
                        playerx = x;
                        playery = y;
                    }
                }
            }

            int dx = 0;
            int dy = 0;

            if (kc == KeyEvent.VK_LEFT)
            {dx = -1;}
            if (kc == KeyEvent.VK_RIGHT)
            {dx = 1;}
            if (kc == KeyEvent.VK_UP)
            {dy = -1;}
            if (kc == KeyEvent.VK_DOWN)
            {dy = 1;}

            if (playerfound == true) 
            {
                if ((gamefield[playerx+dx][playery+dy].tile == BDTile.EMPTY))  
                {
                    gamefield[playerx+dx][playery+dy].tile= BDTile.PLAYER;
                    gamefield[playerx][playery].tile = BDTile.EMPTY;
                }
                else if ((gamefield[playerx+dx][playery+dy].tile == BDTile.DIRT))  
                {
                    gamefield[playerx+dx][playery+dy].tile = BDTile.PLAYER;
                    gamefield[playerx][playery].tile = BDTile.EMPTY;
                } 
                else if ((gamefield[playerx+dx][playery+dy].tile == BDTile.DIAMOND) || (gamefield[playerx+dx][playery+dy].tile == BDTile.FALLINGDIAMOND))  
                {
                    gamefield[playerx+dx][playery+dy].tile = BDTile.PLAYER;
                    gamefield[playerx][playery].tile = BDTile.EMPTY;
                    collectedDiamond ++;

                } 
                else if (((gamefield[playerx+dx][playery+dy].tile == BDTile.ROCK || gamefield[playerx+dx][playery+dy].tile == BDTile.FALLINGROCK)) && (gamefield[playerx+dx+dx][playery+dy+dy].tile == BDTile.EMPTY))  
                {
                    gamefield[playerx+dx+dx][playery+dy+dy].tile = BDTile.ROCK;
                    gamefield[playerx+dx][playery+dy].tile = BDTile.PLAYER;
                    gamefield[playerx][playery].tile = BDTile.EMPTY;
                }

                else if (gamefield[playerx+dx][playery+dy].tile == BDTile.EXIT)
                {   
                    if (collectedDiamond >= numberDiamonds)
                    {
                        gamefield[playerx+dx][playery+dy].tile = BDTile.PLAYER;
                        goLevel++;
                        setLevel(goLevel);
                    }
                }
            }

            if (kc == KeyEvent.VK_R)  
            {
                setLevel(goLevel);
            }  

            if (kc == KeyEvent.VK_N)  
            {
                goLevel++;
                setLevel(goLevel);
            } 

            if (kc == KeyEvent.VK_P)  
            {
                goLevel--;
                setLevel(goLevel);
            }  

            repaint();
            return;
        }
    }

    private class ActionListenerClock implements ActionListener
    {   
        public void actionPerformed(ActionEvent ae) 
        {
            endTime = System.currentTimeMillis();
            period = (endTime - startTime)/1000;

            if (period >= timeLimit)
            {
                setLevel(goLevel);
            }
        }
    }

    private class ActionListenerTimer implements ActionListener
    {
        public void actionPerformed(ActionEvent ae) 
        {
            for (int x = 0; x < WIDTH; x++) 
            {   
                for (int y = HEIGHT - 1; y >= 0; y--) 
                {
                    if (gamefield[x][y].tile == BDTile.ROCK)
                    {
                        if (gamefield[x][y+1].tile == BDTile.EMPTY || gamefield[x][y+1].tile == BDTile.PLAYER || gamefield[x][y+1].tile == BDTile.BUTTERFLY || gamefield[x][y+1].tile == BDTile.FIREFLY)
                        {
                            gamefield[x][y].tile = BDTile.FALLINGROCK;
                        }
                        else if (gamefield[x][y+1].tile == BDTile.WALL || gamefield[x][y+1].tile == BDTile.ROCK || gamefield[x][y+1].tile == BDTile.DIAMOND)
                        { 
                            if (gamefield[x-1][y].tile == BDTile.EMPTY && gamefield[x-1][y+1].tile == BDTile.EMPTY)
                            {
                                gamefield[x-1][y].tile = BDTile.ROCK;
                                gamefield[x][y].tile = BDTile.EMPTY;
                            }
                            else if (gamefield[x+1][y].tile== BDTile.EMPTY && gamefield[x+1][y+1].tile == BDTile.EMPTY)
                            {   
                                gamefield[x+1][y].tile = BDTile.ROCK;
                                gamefield[x][y].tile = BDTile.EMPTY;
                            }
                        }
                    }

                    else if (gamefield[x][y].tile == BDTile.FALLINGROCK) 
                    {
                        if (gamefield[x][y+1].tile == BDTile.BUTTERFLY)
                        {
                            explosion (x,y+1,BDTile.DIAMOND);  
                        }
                        else if (gamefield[x][y+1].tile == BDTile.FIREFLY)
                        {
                            explosion (x,y+1,BDTile.EMPTY);
                        }
                        else if (gamefield[x][y+1].tile == BDTile.DIRT || gamefield[x][y+1].tile == BDTile.WALL || gamefield[x][y+1].tile == BDTile.ROCK || gamefield[x][y+1].tile == BDTile.DIAMOND)
                        {
                            gamefield[x][y].tile = BDTile.ROCK;
                        }
                        else if (gamefield[x][y+1].tile == BDTile.PLAYER)
                        {   
                            gamefield[x][y+1].tile = BDTile.FALLINGROCK;
                            gamefield[x][y].tile = BDTile.EMPTY;
                            playerDied();
                        }
                        else if (gamefield[x][y+1].tile == BDTile.EMPTY)
                        {
                            gamefield[x][y+1].tile = BDTile.FALLINGROCK; 
                            gamefield[x][y].tile = BDTile.EMPTY; 
                        }
                    }

                    else if (gamefield[x][y].tile == BDTile.DIAMOND)
                    {
                        if (gamefield[x][y+1].tile == BDTile.WALL || gamefield[x][y+1].tile == BDTile.ROCK || gamefield[x][y+1].tile == BDTile.DIAMOND)
                        {
                            if (gamefield[x-1][y].tile == BDTile.EMPTY && gamefield[x-1][y+1].tile == BDTile.EMPTY)
                            {
                                gamefield[x-1][y].tile = BDTile.DIAMOND;
                                gamefield[x][y].tile = BDTile.EMPTY;
                            }
                            else if (gamefield[x+1][y].tile == BDTile.EMPTY && gamefield[x+1][y+1].tile == BDTile.EMPTY)
                            {   
                                gamefield[x+1][y].tile = BDTile.DIAMOND;
                                gamefield[x][y].tile = BDTile.EMPTY;
                            }
                        }
                        else if (gamefield[x][y+1].tile == BDTile.EMPTY)
                        {
                            gamefield[x][y].tile = BDTile.FALLINGDIAMOND;
                        } 
                    }

                    else if (gamefield[x][y].tile == BDTile.FALLINGDIAMOND)
                    {
                        if (gamefield[x][y+1].tile == BDTile.PLAYER || gamefield[x][y+1].tile == BDTile.BUTTERFLY || gamefield[x][y+1].tile == BDTile.FIREFLY || gamefield[x][y+1].tile == BDTile.ROCK || 
                        gamefield[x][y+1].tile == BDTile.DIRT || gamefield[x][y+1].tile == BDTile.WALL || gamefield[x][y+1].tile == BDTile.DIAMOND)
                        {
                            gamefield[x][y].tile = BDTile.DIAMOND;
                        }
                        else if (gamefield[x][y+1].tile == BDTile.EMPTY)
                        {
                            gamefield[x][y+1].tile = BDTile.FALLINGDIAMOND; 
                            gamefield[x][y].tile = BDTile.EMPTY;
                        }
                    }

                    else if (gamefield[x][y].tile == BDTile.FIREFLY)
                    {
                        if (gamefield[x+1][y].tile == BDTile.PLAYER || gamefield[x-1][y].tile == BDTile.PLAYER || gamefield[x][y+1].tile == BDTile.PLAYER || gamefield[x][y-1].tile == BDTile.PLAYER)
                        {
                            explosion (x,y,BDTile.EMPTY);
                            playerDied(); 
                        }
                    }
                    else if (gamefield[x][y].tile == BDTile.AMOEBA)
                    {
                        amoebaMoves (x,y);
                    }
                }
            }

            for (int i = 0; i < flies.size(); i++)
            {
                fliesMove(flies.get(i));
            }

            repaint();
        }
    }

    public void fliesMove (BDCell cell)
    {
        int x = cell.x;
        int y = cell.y;
        int a = 0;
        int b = 0;

        if (gamefield[x][y].flyDir == Direction.LEFT)
        {
            a = -1;
            b = 0;
        }

        if (gamefield[x][y].flyDir == Direction.UP)
        {
            a = 0;
            b = -1;
        }

        if (gamefield[x][y].flyDir == Direction.RIGHT)
        {
            a = 1;
            b = 0;
        }

        if (gamefield[x][y].flyDir == Direction.DOWN)
        {
            a = 0;
            b = 1;
        }

        if (gamefield[x+a][y+b].tile == BDTile.EMPTY)
        {
            BDCell temp = gamefield[x+a][y+b];
            gamefield[x+a][y+b] = gamefield[x][y];
            gamefield[x][y] = temp; 

            gamefield[x][y].x = x;
            gamefield[x][y].y = y;
            gamefield[x+a][y+b].x = x+a;
            gamefield[x+a][y+b].y = y+b;
        }

        else if (gamefield[x+a][y+b].tile != BDTile.EMPTY)
        {
            if (gamefield[x][y].tile == BDTile.BUTTERFLY) 
            {
                gamefield[x][y].flyDir = RotateCounterClockwise(gamefield[x][y].flyDir);
            }
            else if (gamefield[x][y].tile == BDTile.FIREFLY) 
            {
                gamefield[x][y].flyDir = RotateClockwise(gamefield[x][y].flyDir);
            }
        }

    }        

    public Direction RotateCounterClockwise(Direction dir)
    {
        if ( dir == Direction.LEFT )
        {
            dir = Direction.DOWN;
        }
        else if (dir == Direction.DOWN)
        {
            dir = Direction.RIGHT;
        }
        else if (dir == Direction.RIGHT )
        {
            dir = Direction.UP;
        }
        else if (dir == Direction.UP)
        {
            dir = Direction.LEFT;
        }

        return dir; 
    }

    public Direction RotateClockwise(Direction dir)
    {
        if ( dir == Direction.LEFT )
        {
            dir = Direction.UP;
        }
        else if (dir == Direction.UP)
        {
            dir = Direction.RIGHT;
        }
        else if (dir == Direction.RIGHT)
        {
            dir = Direction.DOWN;
        }
        else if (dir == Direction.DOWN)
        {
            dir = Direction.LEFT;
        }

        return dir; 

    }

    public void finalize() 
    {
        running = false; 
    }

    public void terminate() 
    {
        timer.stop();
        clock.stop(); 
        running = false; 
    }

    public static void main(String[] args) throws Exception
    {  
        final JFrame f = new JFrame();   
        final BoulderDash bd = new BoulderDash("levels.xml" , f);
        f.add(bd);  
        f.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);  
        f.setLayout(new FlowLayout());
        f.addWindowListener(new WindowAdapter() 
            {
                public void windowClosing(WindowEvent we)
                {
                    bd.terminate();
                    f.dispose();
                }
            }); 
        f.setVisible(true);  
    }  
}

